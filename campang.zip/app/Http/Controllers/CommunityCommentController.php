<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CommunityCommentController extends Controller
{
    //
}
