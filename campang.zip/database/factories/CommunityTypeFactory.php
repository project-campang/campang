<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\CommunityType>
 */
class CommunityTypeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'type' => 1,
            'name' => '자유게시판',
        ];
        // return [
        //     'type' => 2,
        //     'name' => '리뷰게시판',
        // ];
    }
}
