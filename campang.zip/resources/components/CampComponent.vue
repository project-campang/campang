<template>
    <main>
        <div class="background-color">
            <div class="main-head">
                <a href="">HOME</a>
                <p>></p>
                <a href="">캠핑장 모아보기</a>
                <p>></p>
                <a href="">상세정보</a>
            </div>
            <hr>
            <div class="main-body">
                <div class="detail-left">
                    <div class="detail-sticky">
                        <img class="camping-img" :src="$store.state.campDetail.campInfo.main_img" alt="사진">
                        <div class="detail-info-container">
                            <br>
                            <div class="shop-name-card">
                                <div class="shop-name">{{$store.state.campDetail.campInfo.name}}</div>
                                <hr>
                                <div class="shop-name-under">{{$store.state.campDetail.campInfo.info_text}}</div>
                            </div>
                            <div class="shop-info-card">
                                <div class="shop-info-text">
                                    <div class="shop-info-line">
                                        <div class="info-name">캠핑장 주소</div>
                                        <div class="info-text">
                                            {{$store.state.campDetail.campInfo.state}}
                                            {{$store.state.campDetail.campInfo.county}}
                                            {{$store.state.campDetail.campInfo.address}}
                                        </div>
                                    </div>
                                    <div class="shop-info-line">
                                        <div class="info-name">문의처</div>
                                        <div class="info-text">{{$store.state.campDetail.campInfo.tel}}</div>
                                    </div>
                                    <div class="shop-info-line">
                                        <div class="info-name">유형</div>
                                        <div class="info-text">글램핑 / 오토캠핑 / 차박</div>
                                    </div>
                                </div>
                                <div class="shop-info-btn-container">
                                    <div class="shop-info-btn-item">
                                        <button @click="shareBtn()" class="btn-group">
                                            <img class="shop-info-btn" src="../../public/img_nr/공유하기.png" alt="공유">
                                            <div  class="shop-info-btn-name" id="share-btn">공유하기</div>
                                        </button>
                                    </div>
                                    <div class="shop-info-btn-item">
                                        <!-- <button @click="toggleWish" class="btn-group"> -->
                                        <button @click="toggleWish()" class="btn-group">
                                            <img v-if="!isWished"  class="shop-info-btn" src="../../public/img_nr/찜하기.png" alt="찜전">
                                            <img v-else class="shop-info-btn" src="../../public/img_nr/찜하기_활성화.png" alt="찜후">
                                            <div class="shop-info-btn-name">찜하기</div>
                                        </button>
                                    </div>
                                    <div class="shop-info-btn-item">
                                        <a @click="gotoLink()" :href="$store.state.campDetail.campInfo.link" class="btn-group">
                                            <img class="shop-info-btn" src="../../public/img_nr/예약하기.png" alt="예약">
                                            <div class="shop-info-btn-name">예약하기</div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="detail-right">
                    <div class="detail-info-card">
                        <div class="info-card-name">주변환경</div>
                        <div class="info-card-main">
                            <div class="info-icon" v-for="item in $store.state.campDetail.topoInfo" :key="item">
                                <img :src="item.img" alt="icon">
                                <p>{{ item.name }}</p>
                            </div>
                            <!-- <div class="info-icon">
                                <img src="../../public/img_nr/강아이콘.png" alt="icon">
                                <p>강</p>
                            </div> -->
                        </div>
                    </div>
                    <div class="detail-info-card">
                        <div class="info-card-name">이용시설</div>
                        <div class="info-card-main">
                            <div class="info-icon" v-for="item in $store.state.campDetail.amenityInfo" :key="item">
                                <img :src="item.img" alt="icon">
                                <p>{{ item.name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="detail-info-card">
                        <div class="info-card-name">사이트 갯수</div>
                        <div class="info-card-main">
                            <div class="site-info">
                                <div class="info-icon" v-for="item in $store.state.campDetail.siteTypeInfo" :key="item">
                                <img :src="item.img" alt="icon">
                                <p>{{ item.name }}</p>
                                <p>{{ item.cnt }}개</p>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="detail-info-card">
                        <div class="info-card-name">캠핑장 전경</div>
                        <div class="info-card-main camp-img-box">
                            <img v-for="item in 10" :key="item" src="../../public/img/logo-ko3.png" alt="">
                        </div>
                    </div>
                    <hr>
                    <div class="comment-review-tap">
                        <button type="button" class="comment-tap" @click="showCommentTap">댓글</button>
                        <button type="button" class="review-tap" @click="showReviewTap">리뷰</button>
                    </div>
                    <div class="tapUI-container">
                        <div class="comment-container" v-if="detailTapUI">
                            <div class="comment_store">
                                <CommentCreate />
                            </div>
                            <div class="comment-list">
                                <CommentListItem />
                            </div>
                        </div>
                        <div class="review-container" v-else>
                                <CampReviewTap />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</template>
    
    
<script setup>
import CommentCreate from './CommentCreate.vue';
import CommentListItem from './CommentListItem.vue';
import CampReviewTap from './CampReviewTap.vue';
import { onBeforeMount, reactive, ref,computed, onMounted, watchEffect } from 'vue';
import { useStore } from 'vuex';
import { useRoute } from 'vue-router';

const store = useStore();
const route = useRoute();
const routeParams = useRoute().params;

// 컴포넌트가 생성될 때 액션을 호출하여 데이터를 가져옴
onBeforeMount(() => {
  store.dispatch('campDetailGet', route.params.id);
});


// ----------------- 댓글 , 리뷰 ----------------------
let detailTapUI = ref(true);

function showCommentTap() {
    detailTapUI.value = true;
    const element = document.querySelector('.comment-review-tap');
    const reviewTap = document.querySelector('.review-tap');
    const commentTap = document.querySelector('.comment-tap');
    reviewTap.removeAttribute('style');
   
    commentTap.style.cssText  = 'background-color: #B3DC9F;';
}

function showReviewTap() {
    detailTapUI.value = false;
    const element = document.querySelector('.comment-review-tap');
    const reviewTap = document.querySelector('.review-tap');
    const commentTap = document.querySelector('.comment-tap');
    
    commentTap.removeAttribute('style');
    reviewTap.style.cssText  = 'background-color: #B3DC9F;';
}
// ---------------------------------------------------


// ------------------ 공유하기 ------------------------
const shareBtn = () => {
  const url = `http://127.0.0.1:8000/camp/${route.params.id}`;
  console.log(url);
  window.navigator.clipboard.writeText(url).then(() => {
    alert('링크 복사 완료 ! \n 지금 공유 해보세요!');
  }).catch(err => {
    console.error('클립보드에 복사 실패:', err);
  });
};
// ---------------------------------------------------


//---------------------- 찜하기 -----------------------
// const isWished = ref(false);

// watchEffect(() => {
//   isWished.value = store.state.wishes;
// });

const camp_param_id = route.params.id;

function toggleWish(){
    store.dispatch('detailWishToggle', camp_param_id);
    console.log(camp_param_id)
}
// const toggleWish = async () => {
//   const camp_id = 1; // 예시로 고정된 캠핑장 ID
//   await store.dispatch('toggleWish', { user_id: store.state.userInfo.id, camp_id });
// };

// // 컴포넌트가 마운트되면 초기 찜 상태 설정
// onMounted(() => {
// //   const camp_id = 1; // 예시로 고정된 캠핑장 ID
// //   isWished.value = store.state.wish.wishes.some(wish => wish.camp_id === camp_id);

// // const camp_id = route.params.id;
// });
// ---------------------------------------------------


// ------------------- 예약하기 -----------------------
function gotoLink() {
    alert('\n[[캠팡]]은 예약 링크만 제공하며, 서비스는 제공하지 않습니다.\n예약사이트로 이동합니다.');
}
// ---------------------------------------------------
</script>

